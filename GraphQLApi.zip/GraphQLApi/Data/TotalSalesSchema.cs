﻿using GraphQL.Types;
using GraphQLApi.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http.Dependencies;
using GraphQL;
using GraphQL.Types;
namespace GraphQLApi.Data
{
    public class TotalSalesSchema: Schema
    {
        public TotalSalesSchema(IDependencyResolver resolver) : base(resolver)  
        {  
            Query = resolver.Resolve<SalesQuery>();  
        }  
    }
}
