﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GraphQLApi.Data
{
    public class TotalSalesModel
    {
        public string City { get; set; }
        public string Year { get; set; }
        public string ProductName { get; set; }
        public decimal TotalSales { get; set; }
    }
}
