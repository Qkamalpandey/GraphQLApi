﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GraphQLApi.Data
{
    public class TotalSalesRepository:ITotalSalesRepository
    {
        private readonly GraphQLDemoContext _context;
        public TotalSalesRepository(GraphQLDemoContext context)
        {
            _context = context;
        }
        public Task<List<TotalSalesModel>> GetTotalSales()
        {
            return _context.TotalSalesModel.ToListAsync();
        }
    }
}
