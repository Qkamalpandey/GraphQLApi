﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GraphQLApi.Data
{
    public interface ITotalSalesRepository
    {
        Task<List<TotalSalesModel>> GetTotalSales();
    }
}
