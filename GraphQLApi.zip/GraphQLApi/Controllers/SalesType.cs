﻿using GraphQLApi.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GraphQL.Types;
namespace GraphQLApi.Controllers
{
    public class SalesType: ObjectGraphType<TotalSalesModel>
    {
        public SalesType()
        {
            Field(a => a.City);
            Field(a => a.Year);
            Field(a => a.ProductName);
            Field(a => a.TotalSales);
            
        }
    }
}
