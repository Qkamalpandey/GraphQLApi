﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GraphQL.Types;
using GraphQLApi.Data;

namespace GraphQLApi.Controllers
{
    public class SalesQuery: ObjectGraphType
    {
        public SalesQuery(ITotalSalesRepository totalsalesrepository)
        {
            Field<ListGraphType<SalesType>>(
                "totalsales",
                resolve: context => totalsalesrepository.GetTotalSales()
                );
        }
    }
}
